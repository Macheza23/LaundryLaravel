<?php

namespace App\Enums;

enum Role: int
{
    case Admin = 1;
    case Member  = 2;
}
