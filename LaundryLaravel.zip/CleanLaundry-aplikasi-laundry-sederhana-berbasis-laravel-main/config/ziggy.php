<?php

return [
    'groups' => [
        'admin' => ['admin.*'],
        'member' => ['member.*'],
    ],
];
